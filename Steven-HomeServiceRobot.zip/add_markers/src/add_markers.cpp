#include <ros/ros.h>
#include <nav_msgs/Odometry.h>
#include <visualization_msgs/Marker.h>

// Global variables
const double pickupZone[] = /*{-5.49, 4.28}*/ {1,0}; // Pickup point from map frame: [ 1.0,  0.0]
const double dropoffZone[] = /*{3.40,-5.30}*/ {-9,-11}; // Dropoff point from map frame: [-9.0,-11.0]
const double odomPickup[] = {-7.00,0.66};  // Pickup point from odom frame
const double odomDropoff[] = {3.92,-8.93}; // Dropoff point from odom frame
const double errorThres = 0.5;             // Robot may be within 0.5 m radius

bool isPicked = false;
bool isDropped = false;

visualization_msgs::Marker marker;

// Global declaration
ros::Publisher marker_pub;
ros::Subscriber pickup_sub;


// Callback function sets picked condition to true when the robot comes within the threshold distance from the pickup zone
void pickup_callback(const nav_msgs::Odometry odom)
{
    if (sqrt(pow(odom.pose.pose.position.x-odomPickup[0], 2) + pow(odom.pose.pose.position.y-odomPickup[1], 2)) < errorThres){
        isPicked = true;
    }
}


// Callback function sets dropped condition to true when the robot comes within the threshold distance from the dropoff zone
void dropoff_callback(const nav_msgs::Odometry odom)
{
    if (sqrt(pow(odom.pose.pose.position.x-odomDropoff[0], 2) + pow(odom.pose.pose.position.y-odomDropoff[1], 2)) < errorThres){
        isDropped = true;
    }
}



int main( int argc, char** argv )
{
  // Initialize add_markers node and assign node handle
  ros::init(argc, argv, "add_markers");
  ros::NodeHandle n;
  ros::Rate r(1);
  
  // Define marker publisher & odometry subscribers to determine pickup & dropoff status
  ros::Publisher marker_pub = n.advertise<visualization_msgs::Marker>("visualization_marker", 1);
  
  ros::Subscriber pickup_sub = n.subscribe("/odom", 1, pickup_callback);
  ros::Subscriber dropoff_sub = n.subscribe("/odom", 1, dropoff_callback);


    // Set our initial shape type to be a cube
    uint32_t shape = visualization_msgs::Marker::CUBE;

    // Set the frame ID and timestamp.  See the TF tutorials for information on these.
    marker.header.frame_id = "/map";
    marker.header.stamp = ros::Time::now();

    // Set the namespace and id for this marker.  This serves to create a unique ID
    // Any marker sent with the same namespace and id will overwrite the old one
    marker.ns = "add_markers";
    marker.id = 0;

    // Set the marker type.  Initially this is CUBE, and cycles between that and SPHERE, ARROW, and CYLINDER
    marker.type = shape;

    // Set the marker action.  Options are ADD, DELETE, and new in ROS Indigo: 3 (DELETEALL)
    marker.action = visualization_msgs::Marker::ADD;

    // Set the pose of the marker.  This is a full 6DOF pose relative to the frame/time specified in the header
    marker.pose.position.x = pickupZone[0];
    marker.pose.position.y = pickupZone[1];
    marker.pose.position.z = 0;
    marker.pose.orientation.x = 0.0;
    marker.pose.orientation.y = 0.0;
    marker.pose.orientation.z = 0.0;
    marker.pose.orientation.w = 1.0;

    // Set the scale of the marker -- 1x1x1 here means 1m on a side
    marker.scale.x = 0.5;
    marker.scale.y = 0.5;
    marker.scale.z = 0.5;

    // Set the color -- be sure to set alpha to something non-zero!
    marker.color.r = 0.0f;
    marker.color.g = 1.0f;
    marker.color.b = 0.0f;
    marker.color.a = 1.0;

    marker.lifetime = ros::Duration();


    // Publish the marker
    while (marker_pub.getNumSubscribers() < 1)
    {
      if (!ros::ok())
      {
        return 0;
      }
      ROS_WARN_ONCE("Please create a subscriber to the marker");
      sleep(1);
    }
    
    marker_pub.publish(marker);



  while (ros::ok())
  {
    ros::spinOnce();
    if (isPicked){
      
      // Turn off marker
      marker.action = visualization_msgs::Marker::DELETE;
      marker_pub.publish(marker);

      // Set new marker settings
      marker.pose.position.x = dropoffZone[0];
      marker.pose.position.y = dropoffZone[1];
      marker.pose.orientation.w = 1;
      marker.color.r = 0.5f;
      marker.color.g = 0.0f;
      marker.color.b = 0.5f;
      marker.color.a = 1.0;
      
      break;
    }
  }  
    
  while (ros::ok())
  {
    ros::spinOnce();
    if (isDropped){
 
      // Turn on marker when robot reaches drop off zone
      marker.action = visualization_msgs::Marker::ADD;
      marker_pub.publish(marker);
      
      break;
    }
    
    r.sleep();
  }
}
