^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlebot
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.4.2 (2016-12-22)
------------------

2.4.1 (2016-12-22)
------------------

2.4.0 (2016-11-01)
------------------

2.3.12 (2016-06-27)
-------------------

2.3.11 (2015-04-15)
-------------------

2.3.10 (2015-04-02)
-------------------

2.3.9 (2015-03-30)
------------------

2.3.8 (2015-03-23)
------------------

2.3.7 (2015-03-02)
------------------

2.3.6 (2015-02-27)
------------------

2.3.5 (2015-01-12)
------------------

2.3.4 (2015-01-07)
------------------

2.3.3 (2015-01-05)
------------------

2.3.2 (2014-12-30)
------------------
* cleanup metapackage. add teleop and remove laptop battery_monitor
* Contributors: Jihoon Lee

2.3.1 (2014-12-30)
------------------

2.3.0 (2014-11-30)
------------------
* migrate linux_hardware as linux_peripheral_interfaces repo
* adds turtlebot_capabilities package and related changes
* Contributors: Jihoon Lee, Marcus Liebhardt

2.2.2 (2013-10-14)
------------------

2.2.1 (2013-09-14)
------------------
* CMake logic bugfixes.

2.2.0 (2013-08-29)
------------------
* Changelogs at package level.
* Add eclipse project files.

Release 2.1.x - hydro, unstable
===============================

2.1.1 (2013-08-06)
------------------

2.1.0 (2013-07-15)
------------------
* Remove obsolete turtlebot_app_manager, as on Hydro we use rocon_app_manager
